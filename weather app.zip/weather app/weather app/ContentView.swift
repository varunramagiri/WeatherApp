import SwiftUI

struct WeatherDayView: View {
    let day: String
    let weatherIcon: String
    let highTemp: Int
    let lowTemp: Int
    
    var iconColor: Color {
        switch weatherIcon {
        case "sun.max.fill", "cloud.sun.fill":
            return .orange
        case "cloud.fill", "cloud.rain.fill", "cloud.snow.fill", "cloud.bolt.fill":
            return .blue
        default:
            return .white
        }
    }
    
    var body: some View {
        VStack {
            Text(day)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.black)
            Image(systemName: weatherIcon)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
                .foregroundColor(iconColor)
            Text("High: \(highTemp)°")
                .font(.footnote)
                .fontWeight(.bold)
                .foregroundColor(.black)
            Text("Low: \(lowTemp)°")
                .font(.footnote)
                .fontWeight(.bold)
                .foregroundColor(.black)
        }
        .padding(5)
    }
}

struct ContentView: View {
    let weatherData = [
        ("Mon", "sun.max.fill", 70, 50),
        ("Tue", "cloud.rain.fill", 60, 40),
        ("Wed", "cloud.snow.fill", 55, 35),
        ("Thu", "cloud.bolt.fill", 65, 45),
        ("Fri", "sun.max.fill", 72, 52),
        ("Sat", "cloud.sun.fill", 68, 48),
        ("Sun", "cloud.fill", 66, 46)
    ]
    
    var body: some View {
        ZStack {
            Image("weather_background")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Weather App")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(.black)
                
                HStack(spacing: 20) {
                    WeatherDayView(day: weatherData[0].0, weatherIcon: weatherData[0].1, highTemp: weatherData[0].2, lowTemp: weatherData[0].3)
                    WeatherDayView(day: weatherData[1].0, weatherIcon: weatherData[1].1, highTemp: weatherData[1].2, lowTemp: weatherData[1].3)
                }
                
                HStack(spacing: 20) {
                    WeatherDayView(day: weatherData[2].0, weatherIcon: weatherData[2].1, highTemp: weatherData[2].2, lowTemp: weatherData[2].3)
                    WeatherDayView(day: weatherData[3].0, weatherIcon: weatherData[3].1, highTemp: weatherData[3].2, lowTemp: weatherData[3].3)
                    WeatherDayView(day: weatherData[4].0, weatherIcon: weatherData[4].1, highTemp: weatherData[4].2, lowTemp: weatherData[4].3)
                }
                
                HStack(spacing: 20) {
                    WeatherDayView(day: weatherData[5].0, weatherIcon: weatherData[5].1, highTemp: weatherData[5].2, lowTemp: weatherData[5].3)
                    WeatherDayView(day: weatherData[6].0, weatherIcon: weatherData[6].1, highTemp: weatherData[6].2, lowTemp: weatherData[6].3)
                }
            }
        }
    }
}


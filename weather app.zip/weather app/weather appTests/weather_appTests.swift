//
//  weather_appTests.swift
//  weather appTests
//
//  Created by Varun Ramagiri on 10/2/24.
//

import Testing
@testable import weather_app

struct weather_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
